﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class packages_Teacher_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Home_TextChanged(object sender, EventArgs e)
    {
        Response.Redirect("Teacher_Main.aspx");
    }

    protected void Attendence_TextChanged(object sender, EventArgs e)
    {
        Response.Redirect("Teacher_Attendence.aspx");
    }

    protected void FeedBack_TextChanged(object sender, EventArgs e)
    {
        Response.Redirect("Teacher_FeedBack.aspx");
    }

    protected void Marks_TextChanged(object sender, EventArgs e)
    {
        Response.Redirect("Teacher_Marks.aspx");
    }

    protected void Name_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ID_TextChanged(object sender, EventArgs e)
    {

    }

    protected void PhoneNo_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Email_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Address_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Designation_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Department_TextChanged(object sender, EventArgs e)
    {

    }
}