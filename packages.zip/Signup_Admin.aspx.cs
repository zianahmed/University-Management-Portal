﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class packages_Signup_Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void name_func(object sender, EventArgs e)
    {

    }

    protected void email_func(object sender, EventArgs e)
    {

    }

    protected void PhoneNo_func(object sender, EventArgs e)
    {

    }

    protected void Address_func(object sender, EventArgs e)
    {

    }
    protected void password_func(object sender, EventArgs e)
    {

    }

    protected void SignUp_func(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}