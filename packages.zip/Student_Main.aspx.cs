﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class packages_Student_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void Name_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ID_TextChanged(object sender, EventArgs e)
    {

    }

    protected void PhoneNo_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Email_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Address_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Batch_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Degree_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Department_TextChanged(object sender, EventArgs e)
    {

    }

    protected void CGPA_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Home_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Attendence_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Course_Registration_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Marks_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Transcript_TextChanged(object sender, EventArgs e)
    {

    }

    protected void FeedBack_TextChanged(object sender, EventArgs e)
    {

    }
}